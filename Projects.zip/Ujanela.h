//---------------------------------------------------------------------------

#ifndef UjanelaH
#define UjanelaH
//---------------------------------------------------------------------------
class Janela{
	public:
		double xMin;
		double yMin;
		double xMax;
		double yMax;

		Janela(double nxMin, double nyMin, double nxMax, double nyMax);
};
#endif
