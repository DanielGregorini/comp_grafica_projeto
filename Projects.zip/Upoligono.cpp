//---------------------------------------------------------------------------

#pragma hdrstop

#include "Upoligono.h"
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)

void Poligono::desenha(TCanvas *canvas, Janela mundo, Janela vp){

		int xvp, yvp;

        	for (int i = 0; i < pontos.size(); i++) {
					xvp = pontos[i].xW2Vp(mundo, vp);
					yvp = pontos[i].yW2Vp(mundo, vp);
					if (i == 0) {
						canvas->MoveTo(xvp, yvp);
					}

					else
                        canvas->LineTo(xvp, yvp);

			}

		  }

void Poligono::mostra(TListBox *listbox){

    listbox->Items->Add(IntToStr(id) + " - " + tipo + " - " + IntToStr((int)pontos.size()));

}

void Poligono::mostraPontos(TListBox *listbox){

	listbox->Items->Clear();

	for (int i = 0; i < pontos.size(); i++) {

        listbox->Items->Add(pontos[i].mostraPonto());

	}

}
